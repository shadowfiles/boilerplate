window.onload = function () {
	// The functionality to be run when the when the page is loaded. 
}